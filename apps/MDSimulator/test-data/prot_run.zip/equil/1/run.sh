#!/bin/sh
acemd3 --platform GPU input > log.txt 2>&1