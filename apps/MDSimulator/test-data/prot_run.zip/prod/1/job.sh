#!/bin/bash


trap "touch /home/alejandro/Fragalysis/apps/MDSimulator/test/protein/outdir/prod/1/jobqueues.done" EXIT SIGTERM

export CUDA_VISIBLE_DEVICES=0

cd /home/alejandro/Fragalysis/apps/MDSimulator/test/protein/outdir/prod/1
/home/alejandro/Fragalysis/apps/MDSimulator/test/protein/outdir/prod/1/run.sh